#WORKING CODE
#!/usr/bin/python
# -*- coding: utf-8 -*-

from E160_state import *
from E160_robot import *
import math
import time
import numpy as np


class P_controller:

        def __init__(self, robot, logging = True):
                self.robot = robot  # do not delete this line
                self.kp = 0  # k_rho
                self.ka = 0  # k_alpha
                self.kb = 0  # k_beta
                self.logging = logging

                if(logging == True):
                        self.robot.make_headers(['pos_X','posY','posZ','vix','viy','wi','vr','wr'])

                self.set_goal_points()

        #Edit goal point list below, if you click a point using mouse, the points programmed
        #will be washed out
        def set_goal_points(self):
                # here is the example of destination code
                
               # self.robot.state_des.add_destination(x=-100,y= 0,theta=0)
                self.robot.state_des.add_destination(x=-100,y=-200,theta=1.6)   #goal point 1
                self.robot.state_des.add_destination(x=25,y=200,theta=.4)   #goal point 2
                self.robot.state_des.add_destination(x=95,y=-95,theta=1.2)    

        
                                                        

        def track_point(self):

                # All d_ means destination

                (d_posX, d_posY, d_theta) = self.robot.state_des.get_des_state()  # get next destination configuration

                # All c_ means current_

                (c_posX, c_posY, c_theta) = self.robot.state.get_pos_state()  # get current position configuration
                (c_vix, c_viy, c_wi) = self.robot.state.get_global_vel_state() #get current velocity configuration, in the global frame
                (c_v, c_w) = self.robot.state.get_local_vel_state() #get current local velocity configuration

                # Most of your program should be here, compute rho, alpha and beta using d_pos and c_pos
                chngX = d_posX - c_posX
                chngY = d_posY - c_posY
                
                rho = math.sqrt(math.pow(chngX,2) + math.pow(chngY,2))  #rho
                alpha = math.atan2(chngY, chngX ) - c_theta  #alpha
                if(alpha>math.pi):
                    alpha=alpha-2*math.pi
                if(alpha<-math.pi):
                    alpha=alpha+2*math.pi
                beta = - d_theta + alpha +c_theta # beta
                if(beta>math.pi):
                    beta=beta-2*math.pi
                if(beta<-math.pi):
                    beta=beta+2*math.pi


                k_rho = 3  # rho
                k_alpha = 8 # alpha
                k_beta = -1.5 # beta
                assert k_alpha+5/3*k_beta-2/math.pi*k_rho>0

                # set new c_v = k_rho*rho, c_w = k_alpha*alpha + k_beta*beta
                c_v = k_rho*rho 
                c_w = k_alpha*alpha + k_beta*beta

                r=3
                L=12
                trix = np.array([[r/2, r/2], [r/(2*L),-r/(2*L)]])
                invtrix = np.linalg.inv(trix)
                [phi_r, phi_l] = np.matmul(invtrix, [c_v, c_w])

                if (c_v > 90 ):  #maimum c_v = 48 rad/ sec
                   c_v = 90
                if(c_w > 2.5): #maimum c_w = 4 rad/ sec
                   c_w = 2.5
                if (c_v < -90):
                   c_v = -90
                if(c_w < -2.5):
                   c_w = -2.5
                        
                # self.robot.set_motor_control(linear velocity (cm), angular velocity (rad))
                self.robot.set_motor_control(c_v, c_w)  # use this command to set robot's speed in local frame
                
                # you need to write code to find the wheel speed for your c_v, and c_w, the program won't calculate it for you.
                self.robot.send_wheel_speed((round(phi_l))  ,(round(phi_r)) ) #unit rad/s

                

                # use the following to log the variables, use [] to bracket all variables you want to store
                # stored values are in log folder
                if self.logging == True:
                        self.robot.log_data([c_posX,c_posY,c_theta,c_vix,c_viy,c_wi,c_v,c_w])

                if abs(c_posX - d_posX) < 5 and abs(c_posY - d_posY) < 5 and abs(c_theta - d_theta) < .5: #you need to modify the reach way point criteria
                        if(self.robot.state_des.reach_destination()): 
                                print("final goal reached")
                                self.robot.set_motor_control(.0, .0)  # stop the motor
                                return True
                        else:
                                print("one goal point reached, continute to next goal point")
                
                return False
